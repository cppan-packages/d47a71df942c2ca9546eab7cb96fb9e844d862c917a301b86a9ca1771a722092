// 30 may 2015

#define rcTabPageDialog 29000
#define rcFontDialog 29001
#define rcColorDialog 29002

// TODO normalize these

#define rcFontFamilyCombobox 1000
#define rcFontStyleCombobox 1001
#define rcFontSizeCombobox 1002
#define rcFontSamplePlacement 1003

#define rcColorSVChooser 1100
#define rcColorHSlider 1101
#define rcPreview 1102
#define rcOpacitySlider 1103
#define rcH 1104
#define rcS 1105
#define rcV 1106
#define rcRDouble 1107
#define rcRInt 1108
#define rcGDouble 1109
#define rcGInt 1110
#define rcBDouble 1111
#define rcBInt 1112
#define rcADouble 1113
#define rcAInt 1114
#define rcHex 1115
#define rcHLabel 1116
#define rcSLabel 1117
#define rcVLabel 1118
#define rcRLabel 1119
#define rcGLabel 1120
#define rcBLabel 1121
#define rcALabel 1122
#define rcHexLabel 1123
